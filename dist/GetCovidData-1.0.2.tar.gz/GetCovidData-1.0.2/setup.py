import setuptools


setuptools.setup(

    name="GetCovidData",
    version="1.0.2",
    author="Huzaifa Azhar",
    description="A simple python package to get Covid Stats just by using simple commands!",
    readme = "README.md",
    install_requires=["bs4"]
)