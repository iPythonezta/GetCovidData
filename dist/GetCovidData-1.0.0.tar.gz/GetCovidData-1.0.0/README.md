# CovidDataApi
Access covid data with simpple commands
