import setuptools

from pathlib import Path
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setuptools.setup(

    name="GetCovidData",
    version="1.0.3",
    author="Huzaifa Azhar",
    description="A simple python package to get Covid Stats just by using simple commands!",
    readme = "README.md",
    long_description=long_description,
    install_requires=["bs4"]
)